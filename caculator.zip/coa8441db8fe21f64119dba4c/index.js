let a =0
let b = 0
let homePoint = document.getElementById("homePoint")
let guestPoint = document.getElementById("guestPoint")

function addOneH(){
      
        a+=1
        homePoint.textContent=a
}
function addOneG(){
      
        b+=1
        guestPoint.textContent=b
}


function addTwoH(){
        a+=2
        homePoint.textContent=a
    }
function addTwoG(){
        b+=2
        guestPoint.textContent=b
    }
   

function addThreeH(){
        a+=3
        homePoint.textContent=a
    }
function addThreeG(){
        b+=3
        guestPoint.textContent=b
    }


